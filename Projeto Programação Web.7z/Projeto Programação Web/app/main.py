from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
import uvicorn
import os # Import para Debug

# Variável para manipular o FastAPI 
app = FastAPI()

# Montar pasta STATIC, lá ficam o css e as imagens
app.mount("/static", StaticFiles(directory="static"), name="static")

# Pasta HTML
templates = Jinja2Templates(directory="app/templates")

# Redireciona para pagina index
@app.get("/", response_class=HTMLResponse)
def read_home(request: Request):
    print(os.getcwd()) # Debug
    return templates.TemplateResponse("index.html", {"request": request})

# Redireciona para pagina livros
@app.get("/livros", response_class=HTMLResponse)
def read_livros(request: Request):
    return templates.TemplateResponse("livros.html", {"request": request})

# Redireciona para pagina autores
@app.get("/autores", response_class=HTMLResponse)
def read_autores(request: Request):
    return templates.TemplateResponse("autores.html", {"request": request})

# Redireciona para pagina de cadastro
@app.get("/cadastro", response_class=HTMLResponse)
def read_cadastro(request: Request):
    return templates.TemplateResponse("cadastro.html", {"request": request})

# Redireciona para pagina de login
@app.get("/login", response_class=HTMLResponse)
def read_login(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

# Redireciona para pagina de carrinho
@app.get("/carrinho", response_class=HTMLResponse)
def read_carrinho(request: Request):
    return templates.TemplateResponse("carrinho.html", {"request": request})

# Roda o programa
if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=7777)
